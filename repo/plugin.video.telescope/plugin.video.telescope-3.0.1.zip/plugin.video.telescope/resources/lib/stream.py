# -*- coding: utf-8 -*-
"""Local HTTP server: byte-range streaming proxy for Telegram files + JSON-RPC for the plugin.

Streaming design (what keeps playback from stalling):
  * files are read in aligned 1 MiB chunks (Telegram upload.getFile constraints)
  * a shared LRU chunk cache (configurable MB) - seeks back and Kodi's probing requests
    (header, tail 'moov' atom, index) are served from memory
  * parallel read-ahead: while chunk N is being written, chunks N+1..N+K are fetched
    concurrently over several MTProto requests, which multiplies throughput
  * per-chunk retry with fresh requests, so a single slow/failed request never kills playback
"""
import collections
import json
import re
import socket
import threading
import time
from concurrent.futures import Future
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

try:
    from urllib.parse import unquote
except ImportError:  # pragma: no cover
    from urllib import unquote

CHUNK = 1024 * 1024

MIME = {'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'm4v': 'video/mp4', 'avi': 'video/x-msvideo',
        'webm': 'video/webm', 'ts': 'video/mp2t', 'mov': 'video/quicktime', 'wmv': 'video/x-ms-wmv',
        'mpg': 'video/mpeg', 'mpeg': 'video/mpeg', 'flv': 'video/x-flv', '3gp': 'video/3gpp'}


class ChunkStore(object):
    """LRU cache of file chunks with de-duplicated in-flight fetches."""

    def __init__(self, fetch, max_bytes=64 * CHUNK, parallel=4, log=None):
        self.fetch = fetch            # fetch(chat, msg, idx) -> concurrent.futures.Future[bytes]
        self.max_bytes = max_bytes
        self.parallel = max(1, parallel)
        self.log = log or (lambda m: None)
        self.cache = collections.OrderedDict()
        self.size = 0
        self.inflight = {}
        self.lock = threading.Lock()
        self.stats = {'hits': 0, 'miss': 0, 'bytes': 0, 'fetch_time': 0.0}

    def _put(self, key, data):
        with self.lock:
            if key in self.cache:
                return
            self.cache[key] = data
            self.size += len(data)
            while self.size > self.max_bytes and len(self.cache) > 1:
                _, old = self.cache.popitem(last=False)
                self.size -= len(old)

    def put(self, chat, msg, idx, data):
        self._put((chat, msg, idx), data)

    def _start(self, key):
        """Start fetching key unless cached/in-flight. Caller holds no lock."""
        with self.lock:
            if key in self.cache or key in self.inflight:
                return self.inflight.get(key)
            fut = Future()
            self.inflight[key] = fut
        t0 = time.time()

        def done(src):
            try:
                data = src.result()
                self._put(key, data)
                with self.lock:
                    self.stats['bytes'] += len(data)
                    self.stats['fetch_time'] += time.time() - t0
                fut.set_result(data)
            except Exception as exc:  # propagate
                fut.set_exception(exc)
            finally:
                with self.lock:
                    self.inflight.pop(key, None)
        try:
            src = self.fetch(*key)
            src.add_done_callback(done)
        except Exception as exc:
            with self.lock:
                self.inflight.pop(key, None)
            fut.set_exception(exc)
        return fut

    def get(self, chat, msg, idx, timeout=30, retries=3):
        key = (chat, msg, idx)
        for attempt in range(retries + 1):
            with self.lock:
                data = self.cache.get(key)
                if data is not None:
                    self.cache.move_to_end(key)
                    self.stats['hits'] += 1
                    return data
            self.stats['miss'] += 1
            fut = self._start(key)
            if fut is None:
                continue
            try:
                return fut.result(timeout)
            except Exception as exc:
                self.log('chunk %s attempt %d failed: %s' % (idx, attempt + 1, exc))
                with self.lock:
                    if self.inflight.get(key) is fut:
                        self.inflight.pop(key, None)
                time.sleep(0.3 * (attempt + 1))
        raise IOError('chunk %d unavailable' % idx)

    def prefetch(self, chat, msg, first, count, last_idx):
        with self.lock:
            busy = len(self.inflight)
        budget = max(0, self.parallel * 2 - busy)
        for idx in range(first, min(first + count, last_idx + 1)):
            if budget <= 0:
                break
            key = (chat, msg, idx)
            with self.lock:
                if key in self.cache or key in self.inflight:
                    continue
            self._start(key)
            budget -= 1

    def speed(self):
        t = self.stats['fetch_time']
        return (self.stats['bytes'] / t) if t else 0


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32


def parse_range(header, size):
    """Return (start, end) inclusive or None for full content; raises ValueError if unsatisfiable."""
    if not header:
        return None
    m = re.match(r'bytes=(\d*)-(\d*)', header.strip())
    if not m:
        return None
    a, b = m.group(1), m.group(2)
    if a == '' and b == '':
        return None
    if a == '':
        n = int(b)
        start, end = max(0, size - n), size - 1
    else:
        start = int(a)
        end = int(b) if b else size - 1
    end = min(end, size - 1)
    if start >= size or start > end:
        raise ValueError('unsatisfiable')
    return start, end


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'
        server_version = 'TeleScope/1.0'

        def log_message(self, fmt, *args):
            if app.debug:
                app.log('http: ' + fmt % args)

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            if self.path.rstrip('/') != '/rpc':
                return self._json(404, {'error': 'not found'})
            length = int(self.headers.get('Content-Length') or 0)
            try:
                req = json.loads(self.rfile.read(length).decode('utf-8') or '{}')
                if req.get('secret') != app.secret:
                    return self._json(403, {'error': 'forbidden'})
                result = app.rpc(req.get('method'), req.get('params') or {})
                self._json(200, {'result': result})
            except Exception as exc:
                app.log('rpc %s error: %r' % (self.path, exc))
                self._json(200, {'error': '%s: %s' % (type(exc).__name__, exc)})

        def do_GET(self):
            self._stream(head=False)

        def do_HEAD(self):
            self._stream(head=True)

        def _stream(self, head):
            if self.path.startswith('/ping'):
                return self._json(200, {'ok': True})
            m = re.match(r'^/stream/(-?\d+)/(\d+)(?:/([^?]*))?', self.path)
            if not m:
                return self._json(404, {'error': 'not found'})
            chat, msg = int(m.group(1)), int(m.group(2))
            try:
                info = app.file_info(chat, msg)
            except Exception as exc:
                app.log('file info failed: %r' % exc)
                return self._json(502, {'error': str(exc)})
            size = int(info['size'])
            name = unquote(m.group(3) or info.get('file') or '')
            ext = name.rsplit('.', 1)[-1].lower() if '.' in name else ''
            ctype = MIME.get(ext) or info.get('mime') or 'application/octet-stream'
            try:
                rng = parse_range(self.headers.get('Range'), size)
            except ValueError:
                self.send_response(416)
                self.send_header('Content-Range', 'bytes */%d' % size)
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            start, end = rng if rng else (0, size - 1)
            self.send_response(206 if rng else 200)
            self.send_header('Content-Type', ctype)
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Content-Length', str(end - start + 1))
            if rng:
                self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, size))
            self.end_headers()
            if head:
                return
            store = app.store
            last_idx = (size - 1) // CHUNK
            if start == 0 and last_idx > 4:
                # players probe the end of the file (MP4 'moov', MKV cues) right after the header:
                # fetch the tail in the background so that seek is instant.
                store.prefetch(chat, msg, last_idx - 1, 2, last_idx)
            idx = start // CHUNK
            pos = start
            readahead = app.readahead
            try:
                while pos <= end:
                    # keep the pipeline full before blocking on the current chunk
                    store.prefetch(chat, msg, idx, readahead + 1, last_idx)
                    data = store.get(chat, msg, idx, timeout=app.chunk_timeout)
                    off = pos - idx * CHUNK
                    piece = data[off:off + (end - pos + 1)]
                    if not piece:
                        break
                    self.wfile.write(piece)
                    pos += len(piece)
                    idx += 1
            except (BrokenPipeError, ConnectionResetError, socket.timeout, ConnectionAbortedError):
                pass  # player seeked / stopped
            except Exception as exc:
                app.log('stream error at %d: %r' % (pos, exc))
                self.close_connection = True
    return Handler


class App(object):
    """Glue object; the service fills rpc/file_info/fetch."""

    def __init__(self, fetch, file_info, rpc, log, secret, cache_mb=128, parallel=4, readahead=8,
                 chunk_timeout=30, debug=False):
        self.log = log
        self.secret = secret
        self.debug = debug
        self._file_info = file_info
        self.rpc = rpc
        self.readahead = readahead
        self.chunk_timeout = chunk_timeout
        self.store = ChunkStore(fetch, max_bytes=cache_mb * CHUNK, parallel=parallel, log=log)
        self._info_cache = {}
        self.server = None

    def file_info(self, chat, msg):
        key = (chat, msg)
        hit = self._info_cache.get(key)
        if hit and hit[0] > time.time():
            return hit[1]
        info = self._file_info(chat, msg)
        self._info_cache[key] = (time.time() + 1800, info)
        return info

    def serve(self, port):
        last_exc = None
        for p in [port] + list(range(port + 1, port + 20)) + [0]:
            try:
                self.server = _Server(('127.0.0.1', p), make_handler(self))
                break
            except OSError as exc:
                last_exc = exc
        if not self.server:
            raise last_exc
        t = threading.Thread(target=self.server.serve_forever, name='telescope-http', daemon=True)
        t.start()
        return self.server.server_address[1]

    def shutdown(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
