# -*- coding: utf-8 -*-
"""Plugin-side client for the service's JSON-RPC endpoint."""
import time

import requests

from . import common


class RPCError(Exception):
    pass


def _endpoint():
    info = common.read_json(common.PORT_FILE, {}) or {}
    if not info.get('port'):
        raise RPCError('service_down')
    return 'http://127.0.0.1:%d' % info['port'], info.get('secret')


def call(method, timeout=90, **params):
    last = None
    for attempt in range(3):
        try:
            base, secret = _endpoint()
            r = requests.post(base + '/rpc', json={'method': method, 'params': params, 'secret': secret},
                              timeout=timeout)
            data = r.json()
            if 'error' in data:
                raise RPCError(data['error'])
            return data.get('result')
        except (requests.ConnectionError, RPCError) as exc:
            last = exc
            if isinstance(exc, RPCError) and str(exc) != 'service_down':
                raise
            time.sleep(1.0 + attempt)  # service may still be starting
    raise RPCError(str(last))


def stream_url(chat_id, msg_id, filename=''):
    base, _ = _endpoint()
    try:
        from urllib.parse import quote
    except ImportError:  # pragma: no cover
        from urllib import quote
    safe = quote((filename or 'video.mkv').replace('/', '_')[-120:])
    return '%s/stream/%d/%d/%s' % (base, int(chat_id), int(msg_id), safe)
