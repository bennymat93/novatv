# -*- coding: utf-8 -*-
"""NovaTV background service:
 * watch history with date + time for every played item
 * AI Hebrew subtitles when no Hebrew subtitle was found, or on request (player button)
 * every new video starts clean (no subtitles / settings carried over; only 'watched' is kept)
 * periodic IPTV merge
 * open NovaTV on start
"""
import json
import os
import re
import threading
import time
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib.common import monitor

from resources.lib.common import ADDON, T, load, save, now_str, log, PROFILE
from resources.lib.subsnet import discover_server

# Window(10000) properties that belong to ONE video (cleared at every start)
SESSION_PROPS = ('NovaTV.ABLoop', 'NovaTV.Dual', 'NovaTV.SyncMarkAudio', 'NovaTV.SyncMarkSub', 'NovaTV.SubsSource', 'BN.OSDInfo')
HEB_CODES = ('heb', 'he', 'hebrew', 'iw')
WIN = xbmcgui.Window(10000)


def status(text):
    """Status visible to skins as $INFO[Window(Home).Property(NovaTV.AISubs)]."""
    WIN.setProperty('NovaTV.AISubs', text)


def forget_file_settings(path):
    """Kodi remembers subtitle/audio track, delays, zoom ... per file (MyVideos 'settings' table).
    Drop them for a played stream so the next start of any video begins clean (history/watched are kept)."""
    import glob
    import sqlite3
    import xbmcvfs
    dbs = sorted(glob.glob(os.path.join(xbmcvfs.translatePath('special://database/'), 'MyVideos*.db')),
                 key=lambda f: int(re.sub(r'\D', '', os.path.basename(f)) or 0))
    if not dbs or not path:
        return 0
    con = sqlite3.connect(dbs[-1], timeout=10)
    try:
        cur = con.execute("DELETE FROM settings WHERE idFile IN (SELECT files.idFile FROM files JOIN path ON "
                          "files.idPath = path.idPath WHERE path.strPath || files.strFilename = ? OR files.strFilename = ?)",
                          (path, path))
        con.commit()
        return cur.rowcount
    finally:
        con.close()


YT_ID = re.compile(r'(?:[?&]file=|video_id=|youtu\.be/|[?&]v=)([\w-]{11})')


def youtube_id(text):
    m = YT_ID.search(text or '')
    return m.group(1) if m and ('youtube' in text or 'youtu.be' in text) else ''


class Flow:
    """Subtitles for ONE video. A flow never touches a later video: every step checks it still owns the player."""

    def __init__(self, player, forced):
        self.p = player
        self.gen = player.gen
        self.file = player.file
        self.forced = forced
        self.cancelled = False
        self.held = False
        self.held_at = 0
        self.bar = None

    def same_video(self):
        return self.gen == self.p.gen and self.p.active

    def alive(self):
        return self.same_video() and not self.cancelled

    # ------------------------------------------------------------ "subtitles ready before watching"
    def hold(self):
        """pause at the start while Hebrew subtitles are prepared (setting ai_prepare)"""
        if not xbmc.getCondVisibility('Player.Paused'):
            self.p.pause()
        self.held, self.held_at = True, time.time()
        self.bar = xbmcgui.DialogProgressBG()
        self.bar.create('NovaTV', T('sub_check'))

    def still_held(self):
        """the viewer pressing Play ends the hold; never hold longer than 4 min"""
        if self.held and (not xbmc.getCondVisibility('Player.Paused') or time.time() - self.held_at > 240):
            self.release()
        return self.held

    def release(self):
        if self.bar:
            try:
                self.bar.close()
            except Exception:
                pass
            self.bar = None
        if self.held:
            self.held = False
            # only un-pause the video we paused - never the next one
            if self.same_video() and xbmc.getCondVisibility('Player.Paused'):
                self.p.pause()

    def run(self):
        try:
            self._run()
        except RuntimeError as e:          # playback ended while we were still reading it: nothing to do
            log('subtitles: playback ended (%s)' % e)
        except Exception as e:
            log('subtitles: %s' % e, xbmc.LOGWARNING)
        finally:
            self.release()
            if self.p.flow is self and not self.alive():
                status('')

    def _run(self):
        p, mon = self.p, monitor()
        if xbmc.getCondVisibility('PVR.IsPlayingTV | PVR.IsPlayingRadio | VideoPlayer.Content(livetv)'):
            if self.forced:
                xbmcgui.Dialog().notification('NovaTV', T('ai_nolive'), xbmcgui.NOTIFICATION_WARNING, 4000)
            return                                   # live TV: no end, nothing to transcribe ahead
        path = self.file
        network = path.startswith(('http://', 'https://'))
        use_ai = self.forced or ADDON.getSettingBool('ai_subs')
        if not self.forced:
            kind = p.getVideoInfoTag().getMediaType()
            # pause only films and episodes; clips (YouTube, Archive extras) just start
            if use_ai and network and kind in ('movie', 'episode') and ADDON.getSettingBool('ai_prepare'):
                self.hold()
            # this video's own Hebrew track or a human Hebrew subtitle (All_Subs) gets the first chance
            wait = int(ADDON.getSetting('ai_wait') or 25)
            for i in range(wait * 2):
                if mon.waitForAbort(0.5) or not self.alive():
                    return
                if p.has_hebrew():
                    return
                if self.bar:
                    self.bar.update(int(i * 50 / (wait * 2)), 'NovaTV', T('sub_check'))
                self.still_held()
            if not use_ai or not self.alive():
                return
        if not network:
            log('AI subs: not a network stream (%s)' % path[:60])
            if self.forced:
                xbmcgui.Dialog().notification('NovaTV', T('ai_nonet'), xbmcgui.NOTIFICATION_WARNING, 5000)
            return
        import requests
        discover_server()                       # re-find the PC if its address changed
        base = ADDON.getSetting('sub_server').rstrip('/')
        tag = p.getVideoInfoTag()
        job = {'url': path, 'title': tag.getTVShowTitle() or tag.getTitle(), 'season': tag.getSeason(),
               'episode': tag.getEpisode(), 'imdb': tag.getIMDBNumber(), 'tmdb': tag.getUniqueID('tmdb'),
               'position': p.getTime(), 'gemini_key': ADDON.getSetting('gemini_key')}
        # YouTube plays through its local proxy: the PC cannot open that URL - send the video id instead
        mode = WIN.getProperty('NovaTV.AIMode') or 'ai'          # 'mt' = machine translation only (Auto, no AI)
        WIN.clearProperty('NovaTV.AIMode')
        job['mode'] = mode
        yid = youtube_id(path + ' ' + xbmc.getInfoLabel('Player.FilenameAndPath') + ' ' +
                         xbmc.getInfoLabel('Player.FolderPath'))
        if yid:
            job['youtube_id'] = yid
        try:
            r = requests.post(base + '/jobs', json=job, timeout=10)
            r.raise_for_status()
            job_id = r.json()['id']
        except Exception as e:
            log('AI subs server: %s' % e, xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('NovaTV', T('ai_noserver'), xbmcgui.NOTIFICATION_WARNING, 5000)
            return
        xbmcgui.Dialog().notification('NovaTV', T('ai_forced') if self.forced else T('ai_start'),
                                      xbmcgui.NOTIFICATION_INFO, 5000)
        status('%s 0%%' % T('ai_progress'))
        loaded_upto, last_note, down_since, warned = -1.0, 0, 0, False
        other = False       # Hebrew from another source (All_Subs / YouTube captions) arrived before the AI
        ai_dir = os.path.join(PROFILE, 'ai', job_id)
        os.makedirs(ai_dir, exist_ok=True)
        while self.alive() and not mon.abortRequested():
            try:
                r = requests.get('%s/jobs/%s' % (base, job_id), timeout=10)
                if r.status_code == 404:        # server restarted: hand the job over again (it resumes)
                    job['position'] = p.getTime() if self.alive() else job['position']
                    r = requests.post(base + '/jobs', json=job, timeout=10)
                st = r.json()
                down_since, warned = 0, False
            except Exception:
                down_since = down_since or time.time()
                if time.time() - down_since > 120 and not warned:
                    xbmcgui.Dialog().notification('NovaTV', T('ai_noserver'), xbmcgui.NOTIFICATION_WARNING, 5000)
                    warned = True
                    discover_server()
                    base = ADDON.getSetting('sub_server').rstrip('/')
                if mon.waitForAbort(5):
                    return
                continue
            pct = int(st.get('progress', 0))
            status('%s %d%%' % (T('ai_progress'), pct))
            now = time.time()
            if now - last_note > 60 and st.get('state') != 'done':
                xbmcgui.Dialog().notification(T('ai_progress'), '%d%% · %s' % (pct, st.get('stage', '')),
                                              xbmcgui.NOTIFICATION_INFO, 3000, False)
                last_note = now
            ready = float(st.get('ready_until', 0))
            done = st.get('state') == 'done'
            if self.still_held() and self.bar:
                self.bar.update(50 + min(49, pct // 2), 'NovaTV', '%s %d%%' % (T('ai_prepare'), pct))
            # load the first part as soon as it exists, then again for every meaningful new chunk and at the end
            if not self.forced and loaded_upto < 0 and not other and p.has_hebrew():
                # the fastest source wins: keep it on screen, the AI goes on in the background (BN subtitle window)
                other = True
                log('AI subtitles: Hebrew from another source is already showing - AI continues in the background')
            first = loaded_upto < 0 and ready > 0
            if first or ready - loaded_upto >= 120 or (done and ready > loaded_upto):
                try:
                    data = requests.get('%s/jobs/%s/srt' % (base, job_id), timeout=20).content
                    if not self.alive():
                        return
                    if b'-->' not in data:
                        # nothing to show yet: never hand Kodi an empty file ("Unable to create subtitle parser")
                        log('AI subtitles: no cues yet (%d bytes) - not loaded' % len(data))
                        loaded_upto = ready if not done else loaded_upto
                        if done:
                            raise RuntimeError('empty result')
                    else:
                        # a new name per version: Kodi does not reload a path it already has; the name is what
                        # the subtitle list shows ("BN AI" = complete, "BN AI 12m" = first 12 minutes)
                        name = ('BN AI' if job.get('mode') != 'mt' else 'BN auto') + ('' if done else ' %dm' % max(1, int(ready // 60)))
                        srt_path = os.path.join(ai_dir, name + '.he.srt')
                        with open(srt_path, 'wb') as f:
                            f.write(data)
                        WIN.setProperty('NovaTV.AISrt', srt_path)          # the BN subtitle window offers it
                        if not self.forced and (other or WIN.getProperty('NovaTV.SubsChosen') == self.file):
                            # the viewer picked a subtitle by hand: keep it; the AI file waits in the BN menu
                            log('AI subtitles ready up to %ds - kept the viewer\'s choice' % ready)
                            loaded_upto = ready
                        else:
                            before = len(p.getAvailableSubtitleStreams())
                            p.setSubtitles(srt_path)      # adds the file and makes it the active track
                            p.chosen = self.gen
                            p.showSubtitles(True)
                            mon.waitForAbort(1)
                            if not self.same_video() or not p.isPlayingVideo():
                                return              # the video is closing: never touch the player mid-close (crash)
                            shown = len(p.getAvailableSubtitleStreams()) > before or _current_sub_is(name)
                            log('AI subtitles loaded up to %ds (%s)%s' % (ready, 'button' if self.forced else 'auto',
                                                                          '' if shown else ' - Kodi did not list the track'))
                            loaded_upto = ready
                            if done and not shown:
                                raise RuntimeError('player did not accept the subtitle file')
                    if self.still_held() and (done or ready >= job['position'] + 120):
                        self.release()      # the first part is subtitled: start watching
                except Exception as e:
                    log('AI subs load: %s' % e, xbmc.LOGWARNING)
                    if done:
                        status('')
                        xbmcgui.Dialog().notification('NovaTV', T('ai_empty'), xbmcgui.NOTIFICATION_WARNING, 6000)
                        return
            if done and loaded_upto > 0:
                try:                                   # every created subtitle also goes to the subtitle store
                    from resources.lib import player_menus, substore
                    base = substore.video_base(job['title'], job['season'], job['episode'], self.file)
                    with open(srt_path, encoding='utf-8', errors='replace') as f:
                        stored = substore.save(player_menus.subs_folder(), base, 'he', 'auto' if job.get('mode') == 'mt' else 'ai',
                                               text=f.read())
                    WIN.setProperty('NovaTV.PrimaryFile', srt_path)
                    log('subtitle stored: %s' % stored)
                except Exception as e:
                    log('subtitle store: %s' % e, xbmc.LOGWARNING)
            if done:
                status('')
                if loaded_upto > 0:
                    xbmcgui.Dialog().notification('NovaTV', T('ai_ready'), xbmcgui.NOTIFICATION_INFO, 4000)
                else:
                    xbmcgui.Dialog().notification('NovaTV', T('ai_empty'), xbmcgui.NOTIFICATION_WARNING, 6000)
                return
            if st.get('state') == 'error':
                status('')
                xbmcgui.Dialog().notification('NovaTV', '%s: %s' % (T('error'), st.get('error', '')[:80]),
                                              xbmcgui.NOTIFICATION_ERROR, 6000)
                return
            if mon.waitForAbort(5):
                return


def _read_sub(path):
    data = open(path, 'rb').read()
    for enc in ('utf-8-sig', 'cp1255', 'latin-1'):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return ''


def align_job():
    """a subtitle placed by All_Subs (guard v10 sets BN.LastSubFile) is timed for some release, not necessarily this
    file: the subtitle server aligns it to this video's speech (offset + frame-rate drift, server/subalign.py) and the
    synced copy replaces it. Only .srt; nothing happens when the server is away or the file is already in sync."""
    import requests
    win, mon, seen = xbmcgui.Window(10000), monitor(), ''
    while not mon.waitForAbort(2):
        f = win.getProperty('BN.LastSubFile')
        if not f or f == seen:
            continue
        seen = f
        from resources.lib.player_menus import _pl
        p = _pl()                     # the process's ONE Player (per-call Players crashed Kodi)
        try:
            if not f.lower().endswith('.srt') or ADDON.getSetting('auto_align') == 'false' or not p.isPlayingVideo():
                continue
            path = p.getPlayingFile()
            tag = p.getVideoInfoTag()
            spec = {'url': path, 'title': tag.getTVShowTitle() or tag.getTitle(), 'season': tag.getSeason(),
                    'episode': tag.getEpisode(), 'tmdb': tag.getUniqueID('tmdb'), 'srt': _read_sub(f)}
            yid = youtube_id(path + ' ' + xbmc.getInfoLabel('Player.FilenameAndPath'))
            if yid:
                spec['youtube_id'] = yid
            base = ADDON.getSetting('sub_server').rstrip('/')
            if not base:
                continue
            r = requests.post(base + '/align', json=spec, timeout=240).json()
            info = r.get('info') or {}
            log('subtitle align %s: %s' % (os.path.basename(f), info))
            if not r.get('srt') or not p.isPlayingVideo() or p.getPlayingFile() != path:
                continue
            # the viewer (or the AI flow) chose another subtitle meanwhile: keep that choice
            if win.getProperty('NovaTV.SubsChosen') == path or win.getProperty('BN.LastSubFile') != f:
                log('subtitle align: another subtitle was chosen meanwhile - synced copy not loaded')
                continue
            out = os.path.join(PROFILE, 'aligned')
            os.makedirs(out, exist_ok=True)
            name = os.path.splitext(os.path.basename(f))[0]
            name = re.sub(r'\.(he|heb|iw)$', '', name)[:80] + ' BN sync.he.srt'
            dst = os.path.join(out, name)
            with open(dst, 'w', encoding='utf-8') as fh:
                fh.write(r['srt'])
            p.setSubtitles(dst)
            drift = '' if info.get('scale', 1) == 1 else ', fps %.3f' % info['scale']
            xbmcgui.Dialog().notification('NovaTV', T('synced') % (info.get('offset', 0), drift), xbmcgui.NOTIFICATION_INFO, 4000)
        except Exception as e:
            log('subtitle align: %s' % e, xbmc.LOGWARNING)


def _current_sub_is(name):
    """the active subtitle track is the file just loaded (a replaced file of the same name keeps the track count)"""
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                                                        'params': {'playerid': 1, 'properties': ['currentsubtitle']}})))
        return name.split(' ')[0] in ((r.get('result') or {}).get('currentsubtitle') or {}).get('name', '')
    except Exception:
        return False


class Player(xbmc.Player):
    """Every new video starts clean: no subtitles, pause, job or status left over from the previous one.
    Only the history ('watched') is carried over."""

    def __init__(self):
        super().__init__()
        self.gen = 0            # bumped on every start/end: flows of an older video stop by themselves
        self.file = ''
        self.active = False
        self.flow = None
        self.chosen = 0         # gen whose subtitles were deliberately switched on
        self.lock = threading.Lock()

    def playing_file(self):
        try:
            return self.getPlayingFile() if self.isPlayingVideo() else ''
        except RuntimeError:
            return ''

    def onAVStarted(self):
        path = self.playing_file()
        if not path:
            return
        if self.active and path == self.file:
            return          # the same video announced again (stream switch): keep what the viewer chose
        self.begin(path)
        try:
            self.record_history()
        except Exception as e:
            log('history: %s' % e, xbmc.LOGWARNING)
        self.start_flow(forced=False)

    def begin(self, path):
        with self.lock:
            if self.flow:
                self.flow.cancelled = True
            self.gen += 1
            self.file, self.active, self.flow = path, True, None
        status('')
        WIN.clearProperty('NovaTV.AISrt')            # the previous video's AI file is not offered here
        WIN.clearProperty('NovaTV.SubsChosen')
        self.chosen = 0
        gen = self.gen
        try:
            self.showSubtitles(False)      # subtitles must be chosen (or generated) for THIS video
        except RuntimeError:
            pass

        for prop in SESSION_PROPS:                     # everything the panels tied to the previous video
            WIN.clearProperty(prop)

        def zero_state():
            """PlaybackSession start (v1.1.0 phase 5): nothing from the previous video carries over"""
            from resources.lib import playerctl
            if monitor().waitForAbort(0.8) or gen != self.gen:
                return
            try:
                # nothing carries over from the previous video - except this video's own remembered manual offset
                want = playerctl.remembered_delay(self.file)
                if abs(playerctl.sub_delay() - want) > 0.001:
                    playerctl.set_sub_delay(want, remember=False)
                if abs(playerctl.audio_delay()) > 0.001:
                    playerctl.set_audio_delay(0.0)
                if abs(playerctl.speed() - 1.0) > 0.05:
                    playerctl.set_speed(1.0)
                playerctl.reset_view()
                policy = ADDON.getSetting('resume_same') or '0'        # 0 ask (Kodi), 1 always, 2 never
                if policy == '2' and self.getTime() > 5:
                    self.seekTime(0)
                log('session start: %s' % json.dumps(playerctl.state(), ensure_ascii=False))
            except Exception as e:
                log('session reset: %s' % e, xbmc.LOGWARNING)
        threading.Thread(target=zero_state, daemon=True).start()
        threading.Thread(target=self.ab_loop, args=(gen,), daemon=True).start()

        def again():
            # on playlist auto-advance (next episode) Kodi applies the item's saved subtitle state a moment
            # AFTER onAVStarted: switch off again unless this video's subtitles were chosen in the meantime
            for delay in (1.0, 2.0):
                if monitor().waitForAbort(delay) or gen != self.gen or self.chosen == gen or \
                        WIN.getProperty('NovaTV.SubsChosen') == path:
                    return
                try:
                    self.showSubtitles(False)
                except RuntimeError:
                    return
        threading.Thread(target=again, daemon=True).start()

    def ab_loop(self, gen):
        """A-B loop set in the player settings (Window property 'a,b'), bound to this video"""
        while gen == self.gen and not monitor().abortRequested():
            v = WIN.getProperty('NovaTV.ABLoop')
            if ',' in v:
                try:
                    a, b = [float(x) for x in v.split(',')]
                    if self.isPlayingVideo() and self.getTime() >= b:
                        self.seekTime(a)
                except (ValueError, RuntimeError):
                    pass
            if monitor().waitForAbort(0.4):
                return

    def finish(self):
        with self.lock:
            if self.flow:
                self.flow.cancelled = True
            self.gen += 1
            ended, self.file, self.active, self.flow = self.file, '', False, None
        status('')
        if ended.startswith(('http://', 'https://')):
            # Kodi stores the file's settings right after the stop: clear them once it has
            def later():
                monitor().waitForAbort(6)
                try:
                    n = forget_file_settings(ended)
                    if n:
                        log('cleared %d stored player setting(s) of the last video' % n)
                except Exception as e:
                    log('player settings reset: %s' % e, xbmc.LOGWARNING)
            threading.Thread(target=later, daemon=True).start()

    def onPlayBackStopped(self):
        self.finish()

    onPlayBackEnded = onPlayBackStopped
    onPlayBackError = onPlayBackStopped

    def start_flow(self, forced):
        with self.lock:
            if self.flow:
                self.flow.cancelled = True
            flow = self.flow = Flow(self, forced)
        threading.Thread(target=flow.run, daemon=True).start()

    def ai_now(self):
        """'AI subtitles' button: generate Hebrew AI subtitles for this video, even when others exist"""
        path = self.playing_file()
        log('AI subtitles requested for %s' % path[:80])
        if not path:
            xbmcgui.Dialog().notification('NovaTV', T('ai_noplay'), xbmcgui.NOTIFICATION_WARNING, 4000)
            return
        if not (self.active and path == self.file):     # started before the service was running
            with self.lock:
                self.gen += 1
                self.file, self.active = path, True
        self.start_flow(forced=True)

    # ------------------------------------------------------------ history
    def record_history(self):
        if not self.isPlayingVideo():
            return
        tag = self.getVideoInfoTag()
        tmdb_id = tag.getUniqueID('tmdb') or xbmc.getInfoLabel('VideoPlayer.UniqueID(tmdb)')
        show = tag.getTVShowTitle()
        s, e = tag.getSeason(), tag.getEpisode()
        if show and e > 0:
            label = '%s  S%02dE%02d  %s' % (show, s, e, tag.getTitle())
            key = 'tv:%s:%s:%s' % (tmdb_id or show, s, e)
            play = ('plugin://plugin.video.nova/?' + urlencode({'a': 'play', 'm': 'episode', 'id': tmdb_id, 's': s, 'e': e,
                                                                'q': '%s %s' % (show, tag.getTitle())})) if tmdb_id else ''
        else:
            label = tag.getTitle() or xbmc.getInfoLabel('Player.Title')
            key = 'movie:%s' % (tmdb_id or label)
            play = ('plugin://plugin.video.nova/?' + urlencode({'a': 'play', 'm': 'movie', 'id': tmdb_id, 'q': label})) if tmdb_id else ''
        entry = {'key': key, 'label': label, 'when': now_str(), 'ts': time.time(), 'play': play,
                 'plot': tag.getPlot(), 'thumb': xbmc.getInfoLabel('Player.Art(thumb)'),
                 'fanart': xbmc.getInfoLabel('Player.Art(fanart)')}
        hist = [h for h in load('history.json', []) if h.get('key') != key]
        hist.insert(0, entry)
        save('history.json', hist[:2000])

    # ------------------------------------------------------------ subtitles
    def has_hebrew(self):
        """a Hebrew track of the playing video (embedded, or added by All_Subs) -> make it the active one"""
        active = (xbmc.getInfoLabel('VideoPlayer.SubtitlesLanguage') or '').lower()
        if xbmc.getCondVisibility('VideoPlayer.SubtitlesEnabled') and active in HEB_CODES:
            self.chosen = self.gen
            return True
        for i, lang in enumerate(self.getAvailableSubtitleStreams()):
            if (lang or '').lower() in HEB_CODES:
                self.chosen = self.gen
                self.setSubtitleStream(i)
                self.showSubtitles(True)
                return True
        return False


class Monitor(xbmc.Monitor):
    """NotifyAll(plugin.video.nova,ai_now) from the player's AI button / NovaTV"""

    def __init__(self, player):
        super().__init__()
        self.player = player

    def onNotification(self, sender, method, data):
        if sender == 'plugin.video.nova' and method.endswith('ai_now'):
            threading.Thread(target=self.player.ai_now, daemon=True).start()


def main():
    monitor()               # the shared Monitor is created here, on the main thread, and lives until exit
    player = Player()
    mon = Monitor(player)
    try:        # boxes updated from the repository: add the AI subtitle button to the installed skin once
        import xbmcvfs
        from resources.lib import skinpatch
        skin_xml = xbmcvfs.translatePath('special://home/addons/skin.fentastic/xml')
        if os.path.isdir(skin_xml) and skinpatch.apply(skin_xml):
            log('AI subtitle button added to the skin')
            xbmc.executebuiltin('ReloadSkin()')
    except Exception as e:
        log('skin button: %s' % e, xbmc.LOGWARNING)
    try:        # every created subtitle is saved in one folder; Kodi uses it as its subtitle folder too
        from resources.lib import player_menus, playerctl
        folder = player_menus.subs_folder()
        playerctl.rpc('Settings.SetSettingValue', setting='subtitles.storagemode', value=1)
        playerctl.rpc('Settings.SetSettingValue', setting='subtitles.custompath', value=folder)
        from resources.lib import substore
        policy = ['keep_all', 'keep_last', 'older_than'][int(ADDON.getSetting('subs_cleanup') or 0)]
        n = int(ADDON.getSetting('subs_keep_last') or 10)
        gone = substore.cleanup(folder, policy, keep_last=n, older_days=n)
        if gone:
            log('subtitle cleanup: %d file(s)' % len(gone))
    except Exception as e:
        log('subtitle folder: %s' % e, xbmc.LOGWARNING)
    try:        # VLC-style keys (docs/v1.1.0/KEYMAP.md)
        import shutil
        import xbmcvfs
        src = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'keymaps', 'bn_player.xml')
        dst = xbmcvfs.translatePath('special://profile/keymaps/bn_player.xml')
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if not os.path.exists(dst) or open(dst, 'rb').read() != open(src, 'rb').read():
            shutil.copyfile(src, dst)
            xbmc.executebuiltin('Action(reloadkeymaps)')
    except Exception as e:
        log('keymap: %s' % e, xbmc.LOGWARNING)
    def bn_player_job():
        # the BN player is the default with every new version; a viewer's own choice is kept until the next one.
        # Set once the skin is loaded and read back (set too early / a skin update that rewrote its settings
        # left installs updated from the repository on another player style).
        version = ADDON.getAddonInfo('version')
        if ADDON.getSetting('bn_player_ver') == version and xbmc.getInfoLabel('Skin.String(__chooseplayer)'):
            return
        mon = monitor()
        for _ in range(60):
            if xbmc.getCondVisibility('Window.IsVisible(home)'):
                xbmc.executebuiltin('Skin.SetString(__chooseplayer,__bnplayer)')
                if not mon.waitForAbort(1) and xbmc.getInfoLabel('Skin.String(__chooseplayer)') == '__bnplayer':
                    ADDON.setSetting('bn_player_ver', version)
                    log('player style: BN player (version %s)' % version)
                    return
            if mon.waitForAbort(2):
                return
    threading.Thread(target=bn_player_job, daemon=True).start()
    try:        # YouTube's local server port inside a range Windows reserved -> no YouTube playback
        from resources.lib import ytport
        ytport.check(fix=True)
        ytport.ensure_subtitles()
    except Exception as e:
        log('YouTube port: %s' % e, xbmc.LOGWARNING)
    try:        # All_Subs updates itself and loses its guards: put them back (takes effect at its next start)
        import xbmcvfs
        from resources.lib import subspatch
        subs_dir = xbmcvfs.translatePath('special://home/addons/service.subtitles.All_Subs')
        if os.path.isdir(subs_dir) and subspatch.apply(subs_dir):
            log('All_Subs guards applied')
        plus_dir = xbmcvfs.translatePath('special://home/addons/service.subtitles.all_subs_plus')
        if os.path.isdir(plus_dir) and subspatch.apply_plus(plus_dir):
            log('All Subs Plus exit guard applied')
    except Exception as e:
        log('All_Subs guards: %s' % e, xbmc.LOGWARNING)
    threading.Thread(target=discover_server, daemon=True).start()
    if ADDON.getSettingBool('open_on_start'):
        xbmc.sleep(2500)
        xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.nova/,return)')
    def later(delay, job):
        """run a job after a delay in a background thread that never keeps Kodi from quitting
        (threading.Timer is not a daemon: Kodi waited for it on exit, killed the service and could crash)"""
        def run():
            if not monitor().waitForAbort(delay):
                job()
        threading.Thread(target=run, daemon=True).start()

    # Player callbacks are delivered on this thread while it waits, so long jobs
    # (IPTV / EPG download) must run in their own thread.
    def iptv_job():
        try:
            from resources.lib import iptv
            iptv.merge(notify=False)
        except Exception as e:
            log('iptv merge: %s' % e, xbmc.LOGWARNING)

    def backup_job():
        try:
            from resources.lib import backup
            backup.auto_backup()
        except Exception as e:
            log('auto backup: %s' % e, xbmc.LOGWARNING)
    later(600, backup_job)      # 10 min after start, at most once a week

    def gdrive_job():
        # Google Drive (when signed in): sync favourites/history/IPTV between devices, weekly backup to Drive
        try:
            from resources.lib import gdrive_ui
            gdrive_ui.auto()
        except Exception as e:
            log('google drive: %s' % e, xbmc.LOGWARNING)
    later(120, gdrive_job)

    def pvr_ready_job():
        # the TV & Radio home rows reload once the TV service has its channels (their path includes this property)
        # ready = the channel groups are loaded too (PVR.HasTVChannels turns true before them: rows came back empty)
        from resources.lib import iptv
        mon = monitor()
        for _ in range(600):
            try:
                gid = iptv.group_id('Israel')
                n = len(iptv._rpc('PVR.GetChannels', channelgroupid=gid).get('result', {}).get('channels', [])) if gid else 0
            except Exception:
                n = 0
            if n:
                xbmcgui.Window(10000).setProperty('BN.PVRReady', '1')
                return
            if mon.waitForAbort(2):
                return
    later(1, pvr_ready_job)

    def ticker_job():
        # bottom news + weather ticker (resources/lib/ticker.py); the skin shows it while BN.Ticker is set
        from resources.lib import ticker
        from resources.lib.common import ui_lang
        win = xbmcgui.Window(10000)

        def on():
            v = ADDON.getSetting('ticker') != 'false'
            win.setProperty('BN.Ticker', '1' if v else '')
            return v
        try:
            ticker.run(monitor(), on, lambda: ADDON.getSetting('ticker_city') or 'באר שבע',
                       lambda: 'he' if ui_lang() == 'he' else 'en')
        except Exception as e:
            log('ticker: %s' % e, xbmc.LOGWARNING)
    later(3, ticker_job)

    def branding_job():
        # BN name / logo in a plain Kodi: splash, Windows shortcuts, Android offer (resources/lib/branding.py)
        try:
            from resources.lib import branding
            branding.apply()
        except Exception as e:
            log('branding: %s' % e, xbmc.LOGWARNING)
    later(20, branding_job)
    later(5, align_job)

    def profile_job():
        # first start after installation: which device is this? (resources/lib/profiles.py) - never on the test copy
        try:
            from resources.lib import profiles
            if not profiles.current() and 'testkodi' not in xbmcvfs.translatePath('special://xbmc').lower():
                profiles.wizard()
        except Exception as e:
            log('device profile: %s' % e, xbmc.LOGWARNING)
    later(8, profile_job)

    def binary_job():
        # platform-specific add-ons (video streams of YouTube, Pluto, ... need inputstream.adaptive) are not
        # shipped inside the Android app: install the right build for this device from the Kodi repository
        try:
            from resources.lib.iptv import install_addon
            for aid in ('inputstream.adaptive',):
                if not xbmc.getCondVisibility('System.HasAddon(%s)' % aid):
                    log('installing %s for this platform: %s' % (aid, install_addon(aid)))
        except Exception as e:
            log('binary add-ons: %s' % e, xbmc.LOGWARNING)
    later(45, binary_job)

    def startup_job():
        """tell the viewer when everything is up: add-ons, services, how much content"""
        try:
            import json as _json
            start = time.time()
            # a first start installs the TV add-on and loads channels (~2-5 min): announce after that,
            # so the table never shows "0 channels" just because it was too early
            while not mon.abortRequested() and time.time() - start < 420:
                r = _json.loads(xbmc.executeJSONRPC(_json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'PVR.GetChannels',
                                                                'params': {'channelgroupid': 'alltv'}})))
                busy = WIN.getProperty('NovaTV.iptv_busy') == '1'
                if (r.get('result') or {}).get('channels') and not busy and time.time() - start > 20:
                    break
                if mon.waitForAbort(5):
                    return
            while xbmc.getCondVisibility('System.HasActiveModalDialog') and not mon.abortRequested():
                if mon.waitForAbort(2):
                    return
            from resources.lib import status as _status
            data = _status.announce()
            if ADDON.getSettingBool('status_on_start') and not xbmc.getCondVisibility('Player.HasMedia'):
                _status.show_dialog(data)
        except Exception as e:
            log('startup status: %s' % e, xbmc.LOGWARNING)
    threading.Thread(target=startup_job, daemon=True).start()

    def pov_hook_job():
        from resources.lib import providers
        providers.ensure_pov_hook()

    last_iptv = time.time() - 12 * 3600 + 120      # first refresh 2 minutes after start
    last_hook = 0
    while not mon.abortRequested():
        if time.time() - last_hook > 1800:             # POV may have auto-updated: keep NovaTV's fallback hook
            last_hook = time.time()
            threading.Thread(target=pov_hook_job, daemon=True).start()
        hours = int(ADDON.getSetting('iptv_refresh_h') or 12)
        from resources.lib import iptv as _iptv
        if _iptv.all_m3u(_iptv.sources()) and time.time() - last_iptv > hours * 3600:
            last_iptv = time.time()
            threading.Thread(target=iptv_job, daemon=True).start()
        if mon.waitForAbort(5):
            break
    del player


if __name__ == '__main__':
    main()
